var searchData=
[
  ['unityresources',['UnityResources',['../a00074.html#a8d44156e45bb24a02198820a4ce0aed9',1,'Pantagruel::Serializer::SerializerBase']]]
];
