var searchData=
[
  ['builtinresources',['BuiltinResources',['../a00007.html',1,'Pantagruel::Serializer']]]
];
