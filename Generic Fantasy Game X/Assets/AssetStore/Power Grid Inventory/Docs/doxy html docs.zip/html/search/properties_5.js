var searchData=
[
  ['highlightcolor',['HighlightColor',['../a00050.html#a57934fb5bd2d66bcba6711d822f02479',1,'PowerGridInventory::PGISlot']]]
];
