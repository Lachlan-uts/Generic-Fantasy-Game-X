var searchData=
[
  ['gridheight',['GridHeight',['../a00050.html#a66bc2c0c92aea2b97c3cafef7adce8c4',1,'PowerGridInventory::PGISlot']]],
  ['gridwidth',['GridWidth',['../a00050.html#ab6c1f9a8db3010ee8d22a00d7fd2852b',1,'PowerGridInventory::PGISlot']]]
];
