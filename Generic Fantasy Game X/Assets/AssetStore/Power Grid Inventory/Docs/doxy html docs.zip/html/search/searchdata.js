var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvxyz",
  1: "abcdfgiklmoprstux",
  2: "ap",
  3: "acdefghilmoprstux",
  4: "abcdeghimnoprstuvxyz",
  5: "ir",
  6: "abdeghimprsxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties"
};

