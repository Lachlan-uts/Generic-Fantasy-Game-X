var searchData=
[
  ['keyvaluepairsurrogate',['KeyValuePairSurrogate',['../a00035.html',1,'Pantagruel::Serializer::Surrogate']]]
];
