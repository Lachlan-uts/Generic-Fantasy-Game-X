var searchData=
[
  ['xmldeserializer',['XmlDeserializer',['../a00104.html',1,'Pantagruel::Serializer']]],
  ['xmlignorebasetypeattribute',['XmlIgnoreBaseTypeAttribute',['../a00105.html',1,'Pantagruel::Serializer']]],
  ['xmlserializeascustomtypeattribute',['XmlSerializeAsCustomTypeAttribute',['../a00106.html',1,'Pantagruel::Serializer']]],
  ['xmlserializer',['XmlSerializer',['../a00107.html',1,'Pantagruel::Serializer']]]
];
