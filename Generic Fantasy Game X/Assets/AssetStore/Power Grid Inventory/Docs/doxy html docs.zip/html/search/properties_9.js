var searchData=
[
  ['rotated',['Rotated',['../a00052.html#afc8e0fbf9527c583bb25c33f6d85e494',1,'PowerGridInventory::PGISlotItem']]],
  ['rotation',['Rotation',['../a00024.html#ade8718a44b5ef952652d8410b138879c',1,'AncientCraftGames::UI::Image3D']]]
];
